# -*- coding: utf-8 -*-
"""
    Ondemand Korea
"""
from xbmcswift2 import Plugin
import os
import pickle

plugin = Plugin()
_L = plugin.get_string

plugin_path = plugin.addon.getAddonInfo('path')
lib_path = os.path.join(plugin_path, 'resources', 'lib')
sys.path.append(lib_path)

import ondemandkorea as scraper

tPrevPage = u"[B]<<%s[/B]" %_L(30100)
tNextPage = u"[B]%s>>[/B]" %_L(30101)

quality_tbl = ['180p', '240p', '300p', '360p', '480p', '720p', '1080p']

cookiepath = os.path.join(plugin._storage_path, "cookie.pkl")

@plugin.route('/')
def main_menu():
    #urls = scraper.parseTop()
    items = [
        {'label':_L(30110), 'path':plugin.url_for('genre_view', genre='korean-news')},
        {'label':_L(30111), 'path':plugin.url_for('genre_view', genre='drama')},
        {'label':_L(30112), 'path':plugin.url_for('genre_view', genre='variety')},
        {'label':_L(30113), 'path':plugin.url_for('genre_view', genre='documentary')},
        {'label':_L(30126), 'path':plugin.url_for('genre_view', genre='daily-life')},
        {'label':_L(30127), 'path':plugin.url_for('genre_view', genre='senior-tv')},
        {'label':_L(30114), 'path':plugin.url_for('genre_view', genre='food')},
        {'label':_L(30117), 'path':plugin.url_for('genre_view', genre='health')},
        {'label':_L(30128), 'path':plugin.url_for('genre_view', genre='kids')},
        {'label':_L(30119), 'path':plugin.url_for('genre_view', genre='education')},
        {'label':_L(30121), 'path':plugin.url_for('genre_view', genre='religion')},
        #{'label':_L(30129), 'path':plugin.url_for('genre_view', genre='k-pop')},
        {'label':_L(30130), 'path':plugin.url_for('genre_view', genre='kocowa')},
    ]
    if plugin.get_setting('ppv', bool):
        items.insert(0, {'label':_L(30125), 'path':plugin.url_for('movie_view', cate='pay-per-view')})
    #
    if plugin.get_setting("email", str):
        items.append({'label':40*"-"})
        if os.path.exists(cookiepath):
            items.append({'label':_L(30103), 'path':plugin.url_for('logout')})
        else:
            items.append({'label':_L(30102), 'path':plugin.url_for('login')})
    return items

@plugin.route('/genre/<genre>')
def genre_view(genre):
    plugin.log.debug(genre)
    koPage = plugin.get_setting('koPage', bool)
    info = scraper.parseGenre(genre, koPage=koPage, sort="popular")
    items = list()
    for item in info:
        items.append( {'label':item['title'], 'path':plugin.url_for('episode_post', post=item['post']), 'thumbnail':item['thumbnail']} )
    return plugin.finish(items, view_mode='thumbnail')

@plugin.route('/movie/<cate>')
def movie_view(cate):
    koPage = plugin.get_setting('koPage', bool)
    page_url = scraper.root_url+"/"+cate
    url = scraper.extractMovieDataUrlFromPage(page_url, koPage=koPage)
    try:
        with open(cookiepath, 'rb') as f:
            cj = pickle.load(f)
    except:
        cj = None
    info = scraper.parseMoviePage(url, sort="popular", cj=cj)
    items = [{'label':item['title'], 'label2':item['year'], 'path':plugin.url_for('play_episode', url=item['url']), 'thumbnail':item['thumbnail']} for item in info['movie']]
    return plugin.finish(items, view_mode='thumbnail')

@plugin.route('/episode/post/<post>')
def episode_post(post):
    plugin.log.debug(post)
    url = scraper.extractEpisodeDataUrlFromPage(post)
    return plugin.redirect( plugin.url_for('episode_view', url=url) )

@plugin.route('/episode/<url>')
def episode_view(url):
    plugin.log.debug(url)
    info = scraper.parseEpisodePage(url)
    items = [{'label':item['title'], 'label2':item['broad_date'], 'path':plugin.url_for('play_episode', url=item['url']), 'thumbnail':item['thumbnail']} for item in info['episode']]
    # navigation
    if 'prevpage' in info:
        items.append({'label':tPrevPage, 'path':plugin.url_for('episode_view', url=item['prevpage'])})
    if 'nextpage' in info:
        items.append({'label':tNextPage, 'path':plugin.url_for('episode_view', url=item['nextpage'])})
    return plugin.finish(items, update_listing=False)

@plugin.route('/play/<url>')
def play_episode(url):
    global quality_tbl
    plugin.log.debug(url)
    resolution = quality_tbl[ plugin.get_setting('quality', int) ]
    plugin.log.debug("resolution: "+resolution)
    try:
        with open(cookiepath, 'rb') as f:
            cj = pickle.load(f)
    except:
        cj = None
    info = scraper.extractStreamUrl(url, referer=url, cj=cj, fallthru=plugin.get_setting('fallthru',bool))
    avail_resolutions = info['videos'].keys()
    if not resolution in avail_resolutions:
        resolution = avail_resolutions[-1]
    video = info['videos'][resolution]

    plugin.play_video( {'label':info['title'], 'path':video['url']} )

    return plugin.finish(None, succeeded=False)

@plugin.route('/login')
def login():
    email  = plugin.get_setting("email", str)
    passwd = plugin.get_setting("passwd", str)
    if email and passwd:
        plugin.log.debug(cookiepath)
        cj = scraper.loginSess(email, passwd)
        if cj:
            with open(cookiepath, 'wb') as f:
                pickle.dump(cj, f)
    return plugin.finish(None, succeeded=False)

@plugin.route('/logout')
def logout():
    os.remove(cookiepath)
    return plugin.finish(None, succeeded=False)

if __name__ == "__main__":
    plugin.run()

# vim:sw=4:sts=4:et
